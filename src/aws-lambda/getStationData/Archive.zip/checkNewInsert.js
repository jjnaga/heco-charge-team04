const { request } = require('graphql-request')

/** Mutation which inserts new chargedata row */
const query = (insertIntoThisStation, station, session, starttime, endtime, duration, energy, amount, id, port, payment, inputdate, input, validity) => (
  `mutation MyMutation {
    insert_${insertIntoThisStation}(objects: {station: "${station}", id: ${id}, session: "${session}", starttime: "${starttime}", endtime: "${endtime}", duration: "${duration}", energy: "${energy}", amount: "${amount}", port: "${port}", payment: "${payment}", inputdate: "${inputdate}", input: "${input}", validity: "${validity}"}) {
      affected_rows
      returning {
        id
        validity
      }
    }
  }`
);

/** TODO */
function checkForValidity(oldData) {
  const newRow = oldData;

  /** name of table must be inputted here.
   * Tables:
   *  - chargedata
   *  - chargedata-reconcile
   *  - chargedata-bad
   */
  let nameOfTableToInsert = "";

  /** variable shortcuts that update newRow */
  let {
    station,
    session,
    starttime,
    endtime,
    duration,
    energy,
    amount,
    id,
    port,
    payment,
    inputdate,
    input,
    validity } = newRow;

  if (energy <= 0 || duration <= 0 || payment <= 0) {
    nameOfTableToInsert = "chargedata-reconcille"
  }
  else {
    nameOfTableToInsert = "charge-data"
  }
  return nameOfTableToInsert; // name of the table
}

// index.hanlder(lambdaEvent, cb) {}
function mainFunction(lambdaEvent) {
  const endpoint = "https://charge-data.herokuapp.com/v1/graphql";

  /** TODO This doesnt work right now ,fix */
  const newTransactions = lambdaEvent.data; // JSON

  newTransactions.forEach(row => {
    console.log("test" + row);
    let {
      station,
      session,
      starttime,
      endtime,
      duration,
      energy,
      amount,
      id,
      port,
      payment,
      inputdate,
      input,
      validity } = row;


    console.log(`Data:\n${row}`);
    const nameOfTableToInsert = checkForValidity(row);
    console.log(`Inserting into ${nameOfTableToInsert} DB`);

    const newQuery = query(
      nameOfTableToInsert,
      station,
      session,
      starttime,
      endtime,
      duration,
      energy,
      amount,
      id,
      port,
      payment,
      inputdate,
      input,
      validity);

    console.log(newQuery);

    /** send to DB */
    // await request(endpoint, newQuery)
    //   .then(data => {
    //     console.log(data);
    //   }).catch(err => {
    //     console.log(err);
    //   });
  });
}

let hasuraData = require("./db.js");

mainFunction(hasuraData);

